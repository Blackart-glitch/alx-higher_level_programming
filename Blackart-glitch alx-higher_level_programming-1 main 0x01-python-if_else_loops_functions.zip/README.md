# 0x01. Python - if/else, loops, functions

This folder contains code solutions for python hands-on projects that tests on controlled flow, loops and functions.
- [0-positive_or_negative.py](./0-positive_or_negative.py) - a program that states if a randomly assigned number is positive/negative/zero
